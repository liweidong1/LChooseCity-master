# GYZChooseCity
IOS通用城市选择列表，带搜索和定位，效果图如下：
![image](https://github.com/gouyz/GYZChooseCity/blob/master/loadCity.gif)
